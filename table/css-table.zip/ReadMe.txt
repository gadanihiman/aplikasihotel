Author : Muhammad Syakirurohman
URL : http://www.syakirurohman.net
Source : http://www.syakirurohman.net/2015/03/tutorial-membuat-table-html-menarik.html

Lisensi :
Anda bebas menggunakan, memperbanyak, and membagikan bundle ini baik untuk dipakai, diedit ulang, belajar, pelengkap atau digunakan pada proyek komersial. Namun anda tidak berhak menjual bundle ini tanpa izin! 
Jika ingin re-share, harap sertakan file ini dan jangan dirubah..

Hargailah kerja keras orang lain. Terima kasih

Licence :
You are free to use, copy/duplicate, and share this bundle for usage, modifying, learning purpose, and complement of comercial project. But, you are not allowed to sell this bundle.
If you want to re-share, please include this file and do not modified.

Respect Other people work. Thanks